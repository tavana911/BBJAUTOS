# EliteVault Logistics

A VIP luxury consignment and logistics web app — dynamic package tracking, a WhatsApp
concierge widget, and a curated catalog with a consignment intake form, built with
React + Vite + Tailwind + Framer Motion, backed by Supabase (Auth, Postgres, Storage).

## ✨ Features

- **Tracking search** — homepage search bar that looks up a consignment by code
  (`EVL-XXXXX`) and shows a live status pipeline: Pending Review → Received →
  Inspected & Authenticated → Listed for Sale → Sold → Payout Processed.
- **VIP Concierge** — floating WhatsApp chat widget with quick-action presets that
  deep-link into WhatsApp with a pre-filled message.
- **Catalog** — filterable grid of luxury categories with condition badges
  (Pristine / Like New / Certified).
- **Consignment intake** — form with multi-file photo upload to Supabase Storage,
  instantly issuing a tracking number.
- **Demo mode** — the app runs fully in the browser with bundled sample data even
  before Supabase is connected, so you can explore the UI immediately.

## 🛠️ Getting Started

```bash
npm install
cp .env.example .env   # then fill in your Supabase credentials
npm run dev
```

The app runs at `http://localhost:5173`.

Without a `.env` file, the app still runs in **demo mode**: tracking search works
against bundled sample records (try `EVL-89234`, `EVL-40217`, `EVL-10056`), and the
catalog shows bundled sample products. The consignment form still issues a demo
tracking number but won't persist anywhere until Supabase is connected.

## 🗄️ Supabase Setup

1. Create a project at [supabase.com](https://supabase.com).
2. In the SQL Editor, run `supabase/schema.sql`. This creates:
   - `consignments` table (with `consignment_status` enum, indexes, and an
     `updated_at` trigger)
   - `products` table
   - Row Level Security policies (public read for tracking/catalog, public insert
     for new consignment intake, admin-only updates/deletes)
   - The `consignment-photos` Storage bucket with public read + public insert
     policies for uploads
   - A few seed rows so the demo tracking codes work against real data too
3. Copy your project URL and anon public key into `.env`:
   ```
   VITE_SUPABASE_URL=https://your-project-ref.supabase.co
   VITE_SUPABASE_ANON_KEY=your-anon-public-key
   ```

### Admin status updates

The RLS policies restrict `UPDATE`/`DELETE` on `consignments` to authenticated
users whose JWT has `app_metadata.is_admin = true`. To manage this:

- Set the flag via the Supabase Admin API or dashboard:
  `supabase.auth.admin.updateUserById(userId, { app_metadata: { is_admin: true } })`
- Build an internal admin view (not included in this build) that signs staff in via
  Supabase Auth and lets them move a consignment through the pipeline
  (`pending → received → authenticated → listed → sold → paid`).
- Alternatively, update statuses directly from the Supabase Table Editor or via a
  service-role key in a secure backend (never expose the service key client-side).

## 💬 WhatsApp Concierge Setup

Open `src/components/WhatsAppConcierge.jsx` and replace the placeholder number:

```js
const WHATSAPP_NUMBER = '15550123456' // international format, digits only, no + or spaces
```

Each preset button (`Consign an Item`, `Track Package`, `General Inquiry`) opens
`https://wa.me/<number>?text=<pre-filled message>` in a new tab.

## 📁 Project Structure

```
src/
  components/
    Navbar.jsx              Sticky nav + concierge/consign CTAs
    Hero.jsx                Hero section with tracking search
    TrackingSearch.jsx      Tracking input + modal trigger
    TrackingModal.jsx       Tracking result modal
    StatusPipeline.jsx      Visual status pipeline (the "vault seal")
    Catalog.jsx             Filterable product grid
    ConsignSection.jsx      Process steps + intake form wrapper
    ConsignForm.jsx         Intake form with Supabase Storage upload
    WhatsAppConcierge.jsx   Floating WhatsApp chat widget
    Footer.jsx
  lib/
    supabase.js             Supabase client
    consignments.js         Consignment queries + mutations
    products.js              Product queries
    mockData.js              Bundled demo data for offline/dev preview
  App.jsx
  main.jsx
  index.css
supabase/
  schema.sql                 Full SQL schema, RLS policies, storage, seed data
```

## 🚀 Build & Deploy

```bash
npm run build     # outputs to dist/
npm run preview   # preview the production build locally
```

Deploy `dist/` to any static host (Vercel, Netlify, Cloudflare Pages). Set the same
`VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY` environment variables in your host's
dashboard.

## 🎨 Design System

- **Palette** — obsidian black (`#0A0B0D`) base, slate panels, hairline borders, a
  muted antique gold accent (`#C9A24B` / `#E8C878`) and cool silver secondary accent.
- **Type** — Fraunces (display serif) for headlines, Inter for body copy,
  JetBrains Mono for tracking codes and labels.
- **Signature motif** — the status pipeline renders as a "vault seal": a rail of
  locked/unlocked nodes with a traveling gold light, echoed by a slow-rotating
  dial-ring graphic in the hero.
