/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        obsidian: {
          DEFAULT: '#0A0B0D',
          50: '#F5F5F6',
          100: '#E3E4E6',
          200: '#C4C6CA',
          300: '#9A9DA4',
          400: '#6C6F78',
          500: '#45484F',
          600: '#2E3036',
          700: '#1D1F24',
          800: '#141519',
          900: '#0F1013',
          950: '#0A0B0D',
        },
        panel: '#14171C',
        hairline: '#262A31',
        gold: {
          DEFAULT: '#C9A24B',
          light: '#E8C878',
          dim: '#8A6F35',
        },
        silver: {
          DEFAULT: '#9AA3AD',
          light: '#C6CDD4',
        },
        ivory: '#EEEFF1',
      },
      fontFamily: {
        display: ['"Fraunces"', 'ui-serif', 'Georgia', 'serif'],
        body: ['"Inter"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      backgroundImage: {
        'vault-radial':
          'radial-gradient(circle at 50% 0%, rgba(201,162,75,0.10), transparent 55%)',
        'gold-line':
          'linear-gradient(90deg, transparent, rgba(201,162,75,0.9), transparent)',
      },
      boxShadow: {
        gold: '0 0 0 1px rgba(201,162,75,0.35), 0 8px 30px -8px rgba(201,162,75,0.25)',
        panel: '0 4px 40px -12px rgba(0,0,0,0.6)',
      },
      keyframes: {
        dial: {
          '0%': { transform: 'rotate(0deg)' },
          '100%': { transform: 'rotate(360deg)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        pulseGold: {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(201,162,75,0.45)' },
          '50%': { boxShadow: '0 0 0 8px rgba(201,162,75,0)' },
        },
      },
      animation: {
        dial: 'dial 40s linear infinite',
        shimmer: 'shimmer 2.5s linear infinite',
        pulseGold: 'pulseGold 2.4s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}
