-- ==========================================================================
-- EliteVault Logistics — Supabase Schema
-- Run this in the Supabase SQL Editor (or via `supabase db push`).
-- ==========================================================================

create extension if not exists "pgcrypto";

-- --------------------------------------------------------------------------
-- Enum: consignment lifecycle status
-- --------------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from pg_type where typname = 'consignment_status') then
    create type consignment_status as enum (
      'pending',
      'received',
      'authenticated',
      'listed',
      'sold',
      'paid'
    );
  end if;
end $$;

-- --------------------------------------------------------------------------
-- Table: consignments
-- --------------------------------------------------------------------------
create table if not exists public.consignments (
  id                uuid primary key default gen_random_uuid(),
  tracking_number   text not null unique,
  client_name       text not null,
  client_email      text not null,
  item_title        text not null,
  category          text not null,
  status            consignment_status not null default 'pending',
  estimated_value   numeric(12, 2),
  photo_urls        text[] default '{}',
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index if not exists idx_consignments_tracking_number
  on public.consignments (tracking_number);

create index if not exists idx_consignments_status
  on public.consignments (status);

-- Keep updated_at current on every row change
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_consignments_updated_at on public.consignments;
create trigger trg_consignments_updated_at
  before update on public.consignments
  for each row execute function public.set_updated_at();

-- --------------------------------------------------------------------------
-- Table: products
-- --------------------------------------------------------------------------
create table if not exists public.products (
  id            uuid primary key default gen_random_uuid(),
  title         text not null,
  price         numeric(12, 2) not null,
  category      text not null,
  condition     text not null check (condition in ('Pristine', 'Like New', 'Certified')),
  image_url     text,
  is_available  boolean not null default true,
  created_at    timestamptz not null default now()
);

create index if not exists idx_products_category on public.products (category);
create index if not exists idx_products_is_available on public.products (is_available);

-- ==========================================================================
-- Row Level Security
-- ==========================================================================
alter table public.consignments enable row level security;
alter table public.products enable row level security;

-- ---- consignments -----------------------------------------------------
-- Public tracking lookups are allowed by tracking_number, but this policy
-- is intentionally broad at the row level (Postgres RLS can't filter by
-- "only if you know the tracking number" — that's enforced in the app by
-- always querying with .eq('tracking_number', ...)). Restrict the exposed
-- columns via a view if you want to hide client PII from anonymous reads.
drop policy if exists "Public can read consignments for tracking" on public.consignments;
create policy "Public can read consignments for tracking"
  on public.consignments
  for select
  to anon, authenticated
  using (true);

-- Anyone (including anonymous visitors) can submit a new consignment intake.
drop policy if exists "Public can insert consignments" on public.consignments;
create policy "Public can insert consignments"
  on public.consignments
  for insert
  to anon, authenticated
  with check (status = 'pending');

-- Only authenticated staff/admins can update status or any other field.
-- Requires a `profiles` table (or custom claim) marking admins — adjust to
-- your auth setup. Shown here using a `is_admin` boolean on `auth.users`
-- app_metadata as an example.
drop policy if exists "Admins can update consignments" on public.consignments;
create policy "Admins can update consignments"
  on public.consignments
  for update
  to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean is true)
  with check ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean is true);

drop policy if exists "Admins can delete consignments" on public.consignments;
create policy "Admins can delete consignments"
  on public.consignments
  for delete
  to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean is true);

-- ---- products -----------------------------------------------------------
drop policy if exists "Public can read available products" on public.products;
create policy "Public can read available products"
  on public.products
  for select
  to anon, authenticated
  using (is_available = true);

drop policy if exists "Admins manage products" on public.products;
create policy "Admins manage products"
  on public.products
  for all
  to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean is true)
  with check ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean is true);

-- ==========================================================================
-- Storage: consignment reference photos
-- ==========================================================================
insert into storage.buckets (id, name, public)
values ('consignment-photos', 'consignment-photos', true)
on conflict (id) do nothing;

drop policy if exists "Public can upload consignment photos" on storage.objects;
create policy "Public can upload consignment photos"
  on storage.objects
  for insert
  to anon, authenticated
  with check (bucket_id = 'consignment-photos');

drop policy if exists "Public can view consignment photos" on storage.objects;
create policy "Public can view consignment photos"
  on storage.objects
  for select
  to anon, authenticated
  using (bucket_id = 'consignment-photos');

-- ==========================================================================
-- Seed data (optional — remove in production)
-- ==========================================================================
insert into public.products (title, price, category, condition, image_url, is_available)
values
  ('Chanel Classic Flap Medium, Caviar', 8200, 'High-End Handbags', 'Pristine',
   'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=800&auto=format&fit=crop', true),
  ('Rolex Daytona Panda Dial', 34500, 'Luxury Watches', 'Like New',
   'https://images.unsplash.com/photo-1547996160-81dfa63595aa?q=80&w=800&auto=format&fit=crop', true),
  ('Van Cleef & Arpels Alhambra Bracelet', 6100, 'Fine Jewelry', 'Certified',
   'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=800&auto=format&fit=crop', true)
on conflict do nothing;

insert into public.consignments (tracking_number, client_name, client_email, item_title, category, status, estimated_value)
values
  ('EVL-89234', 'A. Whitfield', 'a.whitfield@example.com', 'Hermès Birkin 30 Togo Leather', 'High-End Handbags', 'authenticated', 18500),
  ('EVL-40217', 'R. Okafor', 'r.okafor@example.com', 'Patek Philippe Nautilus 5711', 'Luxury Watches', 'listed', 142000),
  ('EVL-10056', 'M. Delacroix', 'm.delacroix@example.com', 'Cartier Panthère Diamond Necklace', 'Fine Jewelry', 'paid', 26900)
on conflict (tracking_number) do nothing;
