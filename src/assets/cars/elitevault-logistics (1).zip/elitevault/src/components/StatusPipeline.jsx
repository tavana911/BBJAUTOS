import { motion } from 'framer-motion'
import { Check, Lock } from 'lucide-react'
import { STATUS_STEPS } from '../lib/consignments'

export default function StatusPipeline({ status }) {
  const currentIndex = STATUS_STEPS.findIndex((s) => s.key === status)

  return (
    <div className="w-full">
      {/* Desktop / tablet: horizontal rail */}
      <div className="hidden sm:block">
        <div className="relative flex items-start justify-between">
          <div className="absolute left-0 right-0 top-4 h-px bg-hairline" />
          <motion.div
            className="absolute left-0 top-4 h-px bg-gradient-to-r from-gold-dim via-gold to-gold-light"
            initial={{ width: 0 }}
            animate={{
              width: `${currentIndex <= 0 ? 0 : (currentIndex / (STATUS_STEPS.length - 1)) * 100}%`,
            }}
            transition={{ duration: 1, ease: 'easeOut' }}
          />
          {STATUS_STEPS.map((step, i) => {
            const done = i < currentIndex
            const active = i === currentIndex
            return (
              <div key={step.key} className="relative z-10 flex w-full flex-col items-center px-1 text-center">
                <div
                  className={[
                    'flex h-8 w-8 items-center justify-center rounded-full border transition-all duration-500',
                    done
                      ? 'border-gold bg-gold text-obsidian-950'
                      : active
                      ? 'animate-pulseGold border-gold bg-obsidian-900 text-gold'
                      : 'border-hairline bg-obsidian-900 text-obsidian-400',
                  ].join(' ')}
                >
                  {done ? <Check size={14} strokeWidth={3} /> : <Lock size={12} />}
                </div>
                <p
                  className={[
                    'mt-3 max-w-[6.5rem] font-mono text-[10px] uppercase leading-tight tracking-wider',
                    done || active ? 'text-ivory' : 'text-obsidian-400',
                  ].join(' ')}
                >
                  {step.label}
                </p>
              </div>
            )
          })}
        </div>
      </div>

      {/* Mobile: vertical rail */}
      <div className="sm:hidden">
        <div className="relative pl-8">
          <div className="absolute left-[15px] top-2 bottom-2 w-px bg-hairline" />
          <motion.div
            className="absolute left-[15px] top-2 w-px bg-gradient-to-b from-gold-dim via-gold to-gold-light"
            initial={{ height: 0 }}
            animate={{
              height:
                currentIndex <= 0
                  ? 0
                  : `${(currentIndex / (STATUS_STEPS.length - 1)) * 100}%`,
            }}
            transition={{ duration: 1, ease: 'easeOut' }}
            style={{ bottom: '0.5rem' }}
          />
          <div className="flex flex-col gap-6">
            {STATUS_STEPS.map((step, i) => {
              const done = i < currentIndex
              const active = i === currentIndex
              return (
                <div key={step.key} className="relative flex items-center gap-4">
                  <div
                    className={[
                      'absolute -left-8 flex h-8 w-8 items-center justify-center rounded-full border transition-all duration-500',
                      done
                        ? 'border-gold bg-gold text-obsidian-950'
                        : active
                        ? 'animate-pulseGold border-gold bg-obsidian-900 text-gold'
                        : 'border-hairline bg-obsidian-900 text-obsidian-400',
                    ].join(' ')}
                  >
                    {done ? <Check size={14} strokeWidth={3} /> : <Lock size={12} />}
                  </div>
                  <p
                    className={[
                      'font-mono text-xs uppercase tracking-wider',
                      done || active ? 'text-ivory' : 'text-obsidian-400',
                    ].join(' ')}
                  >
                    {step.label}
                  </p>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
