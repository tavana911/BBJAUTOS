import { useState } from 'react'
import { motion } from 'framer-motion'
import { UploadCloud, CheckCircle2, Copy, X } from 'lucide-react'
import {
  createConsignment,
  uploadConsignmentPhotos,
  generateTrackingNumber,
} from '../lib/consignments'

const CATEGORIES = ['High-End Handbags', 'Luxury Watches', 'Fine Jewelry', 'Collector Apparel']

const initialForm = {
  client_name: '',
  client_email: '',
  item_title: '',
  category: CATEGORIES[0],
  estimated_value: '',
}

export default function ConsignForm() {
  const [form, setForm] = useState(initialForm)
  const [files, setFiles] = useState([])
  const [submitting, setSubmitting] = useState(false)
  const [result, setResult] = useState(null) // { trackingNumber } | null
  const [error, setError] = useState(null)
  const [copied, setCopied] = useState(false)

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }))
  }

  function handleFileChange(e) {
    const selected = Array.from(e.target.files ?? [])
    setFiles((prev) => [...prev, ...selected].slice(0, 6))
  }

  function removeFile(index) {
    setFiles((prev) => prev.filter((_, i) => i !== index))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitting(true)
    setError(null)

    const trackingNumber = generateTrackingNumber()

    const { urls, error: uploadError } = await uploadConsignmentPhotos(files, trackingNumber)
    if (uploadError) {
      setError(uploadError)
      setSubmitting(false)
      return
    }

    const { data, error: insertError } = await createConsignment({
      tracking_number: trackingNumber,
      client_name: form.client_name,
      client_email: form.client_email,
      item_title: form.item_title,
      category: form.category,
      status: 'pending',
      estimated_value: form.estimated_value ? Number(form.estimated_value) : null,
      photo_urls: urls,
    })

    setSubmitting(false)

    if (insertError && !insertError.demo) {
      setError(insertError)
      return
    }

    // In demo mode (no Supabase configured) we still confirm the intake locally
    // so the flow is fully explorable — swap in real error handling once connected.
    setResult({ trackingNumber: data?.tracking_number ?? trackingNumber })
    setForm(initialForm)
    setFiles([])
  }

  function copyTracking() {
    if (!result) return
    navigator.clipboard?.writeText(result.trackingNumber)
    setCopied(true)
    setTimeout(() => setCopied(false), 1800)
  }

  if (result) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="panel mx-auto max-w-lg rounded-lg p-8 text-center"
      >
        <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-full border border-gold/40 bg-gold/10 text-gold">
          <CheckCircle2 size={26} />
        </div>
        <h3 className="font-display text-2xl text-ivory">Intake Received</h3>
        <p className="mt-3 text-sm text-obsidian-300">
          Your item has entered our vault pipeline. Save your tracking code to monitor
          progress in real time.
        </p>
        <div className="mt-6 flex items-center justify-center gap-3 rounded-md border border-hairline bg-obsidian-900/60 px-5 py-3">
          <span className="font-mono text-lg tracking-widest text-gold">
            {result.trackingNumber}
          </span>
          <button
            onClick={copyTracking}
            className="text-obsidian-300 transition hover:text-gold"
            aria-label="Copy tracking code"
          >
            <Copy size={16} />
          </button>
        </div>
        {copied && <p className="mt-2 font-mono text-[10px] text-gold">Copied to clipboard</p>}
        <button onClick={() => setResult(null)} className="btn-ghost mt-8 w-full">
          Submit Another Item
        </button>
      </motion.div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="panel mx-auto max-w-2xl rounded-lg p-6 sm:p-9">
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <div className="sm:col-span-1">
          <label className="mb-2 block font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
            Full Name
          </label>
          <input
            required
            value={form.client_name}
            onChange={(e) => update('client_name', e.target.value)}
            type="text"
            placeholder="Alexandra Whitfield"
            className="w-full rounded-md border border-hairline bg-obsidian-900/60 px-4 py-3 text-sm text-ivory placeholder:text-obsidian-500 focus:border-gold/50 focus:outline-none"
          />
        </div>
        <div className="sm:col-span-1">
          <label className="mb-2 block font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
            Email
          </label>
          <input
            required
            value={form.client_email}
            onChange={(e) => update('client_email', e.target.value)}
            type="email"
            placeholder="you@example.com"
            className="w-full rounded-md border border-hairline bg-obsidian-900/60 px-4 py-3 text-sm text-ivory placeholder:text-obsidian-500 focus:border-gold/50 focus:outline-none"
          />
        </div>

        <div className="sm:col-span-2">
          <label className="mb-2 block font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
            Item Title
          </label>
          <input
            required
            value={form.item_title}
            onChange={(e) => update('item_title', e.target.value)}
            type="text"
            placeholder="Hermès Birkin 30 Togo Leather"
            className="w-full rounded-md border border-hairline bg-obsidian-900/60 px-4 py-3 text-sm text-ivory placeholder:text-obsidian-500 focus:border-gold/50 focus:outline-none"
          />
        </div>

        <div className="sm:col-span-1">
          <label className="mb-2 block font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
            Category
          </label>
          <select
            value={form.category}
            onChange={(e) => update('category', e.target.value)}
            className="w-full rounded-md border border-hairline bg-obsidian-900/60 px-4 py-3 text-sm text-ivory focus:border-gold/50 focus:outline-none"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c} className="bg-obsidian-900">
                {c}
              </option>
            ))}
          </select>
        </div>

        <div className="sm:col-span-1">
          <label className="mb-2 block font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
            Estimated Value (USD)
          </label>
          <input
            value={form.estimated_value}
            onChange={(e) => update('estimated_value', e.target.value)}
            type="number"
            min="0"
            placeholder="12000"
            className="w-full rounded-md border border-hairline bg-obsidian-900/60 px-4 py-3 text-sm text-ivory placeholder:text-obsidian-500 focus:border-gold/50 focus:outline-none"
          />
        </div>

        <div className="sm:col-span-2">
          <label className="mb-2 block font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
            Reference Photos
          </label>
          <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-md border border-dashed border-hairline bg-obsidian-900/40 px-4 py-8 text-center transition hover:border-gold/50">
            <UploadCloud size={22} className="text-gold" />
            <p className="text-sm text-obsidian-300">Click to upload, up to 6 images</p>
            <p className="font-mono text-[10px] uppercase tracking-wider text-obsidian-500">
              JPG, PNG — 10MB max each
            </p>
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileChange}
              className="hidden"
            />
          </label>

          {files.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              {files.map((file, i) => (
                <span
                  key={`${file.name}-${i}`}
                  className="flex items-center gap-2 rounded-full border border-hairline bg-obsidian-900/60 px-3 py-1.5 text-xs text-obsidian-200"
                >
                  {file.name.length > 22 ? `${file.name.slice(0, 22)}…` : file.name}
                  <button
                    type="button"
                    onClick={() => removeFile(i)}
                    className="text-obsidian-400 hover:text-red-400"
                    aria-label={`Remove ${file.name}`}
                  >
                    <X size={12} />
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {error && (
        <p className="mt-5 rounded-md border border-red-900/40 bg-red-950/20 px-4 py-3 text-xs text-red-300">
          {error.message}
        </p>
      )}

      <button type="submit" disabled={submitting} className="btn-gold mt-8 w-full disabled:opacity-60">
        {submitting ? 'Submitting…' : 'Submit for Consignment'}
      </button>
      <p className="mt-4 text-center font-mono text-[10px] uppercase tracking-wider text-obsidian-500">
        A tracking code will be issued immediately upon submission
      </p>
    </form>
  )
}
