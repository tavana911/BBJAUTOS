import { useState } from 'react'
import { Search, ArrowRight } from 'lucide-react'
import { getConsignmentByTrackingNumber } from '../lib/consignments'
import TrackingModal from './TrackingModal'

export default function TrackingSearch({ variant = 'hero' }) {
  const [code, setCode] = useState('')
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [consignment, setConsignment] = useState(null)
  const [error, setError] = useState(null)

  async function handleTrack(e) {
    e.preventDefault()
    if (!code.trim()) return

    setOpen(true)
    setLoading(true)
    setError(null)
    setConsignment(null)

    const { data, error: err } = await getConsignmentByTrackingNumber(code)

    if (err || !data) {
      setError(err ?? { message: 'not_found' })
    } else {
      setConsignment(data)
    }
    setLoading(false)
  }

  const isHero = variant === 'hero'

  return (
    <>
      <form
        onSubmit={handleTrack}
        className={[
          'flex w-full items-stretch overflow-hidden rounded-sm border transition-colors',
          isHero
            ? 'border-obsidian-600 bg-obsidian-900/70 backdrop-blur-md focus-within:border-gold/60'
            : 'border-hairline bg-panel focus-within:border-gold/60',
        ].join(' ')}
      >
        <div className="flex items-center pl-4 text-obsidian-400">
          <Search size={17} />
        </div>
        <input
          value={code}
          onChange={(e) => setCode(e.target.value)}
          type="text"
          placeholder="Enter tracking code, e.g. EVL-89234"
          className="w-full bg-transparent px-3 py-4 font-mono text-sm text-ivory placeholder:text-obsidian-500 focus:outline-none"
          aria-label="Consignment tracking code"
        />
        <button
          type="submit"
          className="flex items-center gap-2 whitespace-nowrap bg-gold px-5 py-4 font-body text-sm font-semibold uppercase tracking-[0.12em] text-obsidian-950 transition hover:bg-gold-light"
        >
          Track
          <ArrowRight size={15} />
        </button>
      </form>

      <TrackingModal
        open={open}
        onClose={() => setOpen(false)}
        loading={loading}
        consignment={consignment}
        error={error}
        queriedCode={code}
      />
    </>
  )
}
