import { motion } from 'framer-motion'
import { ArrowRight, Sparkles } from 'lucide-react'
import TrackingSearch from './TrackingSearch'

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pb-20 pt-32 sm:pb-28 sm:pt-40">
      <div className="pointer-events-none absolute inset-0 bg-vault-radial" />

      {/* signature vault-dial motif */}
      <div className="pointer-events-none absolute -right-40 -top-40 hidden opacity-[0.14] md:block lg:-right-24">
        <svg width="620" height="620" viewBox="0 0 620 620" fill="none" className="animate-dial">
          <circle cx="310" cy="310" r="300" stroke="#C9A24B" strokeWidth="1" />
          <circle cx="310" cy="310" r="240" stroke="#C9A24B" strokeWidth="1" />
          {Array.from({ length: 24 }).map((_, i) => {
            const angle = (i / 24) * Math.PI * 2
            const x1 = 310 + Math.cos(angle) * 300
            const y1 = 310 + Math.sin(angle) * 300
            const x2 = 310 + Math.cos(angle) * 288
            const y2 = 310 + Math.sin(angle) * 288
            return (
              <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#C9A24B" strokeWidth="1" />
            )
          })}
        </svg>
      </div>

      <div className="container-vault relative">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="mb-6 inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/5 px-4 py-1.5"
        >
          <Sparkles size={13} className="text-gold" />
          <span className="font-mono text-[10px] uppercase tracking-[0.24em] text-gold">
            By Invitation-Grade Service
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-3xl font-display text-5xl font-light leading-[1.05] text-ivory sm:text-6xl lg:text-7xl"
        >
          Elite<span className="text-gold">Vault</span> Logistics
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="mt-6 max-w-xl text-base text-obsidian-200 sm:text-lg"
        >
          White-glove VIP consignment and secure asset tracking — from intake to
          authentication to payout, every step sealed and accounted for.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          id="track"
          className="mt-10 max-w-xl"
        >
          <TrackingSearch variant="hero" />
          <p className="mt-3 font-mono text-[11px] uppercase tracking-wider text-obsidian-400">
            Try a demo code — EVL-89234 · EVL-40217 · EVL-10056
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="mt-8 flex flex-wrap items-center gap-4"
        >
          <a href="#consign" className="btn-gold">
            Consign With Us
            <ArrowRight size={15} />
          </a>
          <a href="#catalog" className="btn-ghost">
            View Catalog
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="mt-20 grid grid-cols-2 gap-8 border-t border-hairline pt-8 sm:grid-cols-4"
        >
          {[
            ['12K+', 'Assets Vaulted'],
            ['$210M+', 'Consigned Value'],
            ['48H', 'Avg. Authentication'],
            ['99.7%', 'Client Retention'],
          ].map(([stat, label]) => (
            <div key={label}>
              <p className="font-display text-2xl text-ivory sm:text-3xl">{stat}</p>
              <p className="mt-1 font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
                {label}
              </p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
