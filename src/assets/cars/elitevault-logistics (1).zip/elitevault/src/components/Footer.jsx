import { ShieldCheck, Mail, Phone, MapPin, Instagram, Linkedin } from 'lucide-react'

export default function Footer() {
  return (
    <footer id="contact" className="border-t border-hairline bg-obsidian-950">
      <div className="container-vault py-16">
        <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <a href="#top" className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-full border border-gold/50 text-gold">
                <ShieldCheck size={15} />
              </span>
              <span className="font-display text-lg tracking-wide text-ivory">
                Elite<span className="text-gold">Vault</span>
              </span>
            </a>
            <p className="mt-4 max-w-xs text-sm text-obsidian-400">
              White-glove VIP consignment and secure asset tracking for the world's most
              discerning collectors.
            </p>
            <div className="mt-5 flex gap-3">
              <a
                href="#"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-hairline text-obsidian-300 transition hover:border-gold/50 hover:text-gold"
                aria-label="Instagram"
              >
                <Instagram size={15} />
              </a>
              <a
                href="#"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-hairline text-obsidian-300 transition hover:border-gold/50 hover:text-gold"
                aria-label="LinkedIn"
              >
                <Linkedin size={15} />
              </a>
            </div>
          </div>

          <div>
            <p className="font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
              Navigate
            </p>
            <div className="mt-4 flex flex-col gap-3">
              {['Track', 'Consign', 'Catalog', 'Contact'].map((l) => (
                <a
                  key={l}
                  href={`#${l.toLowerCase()}`}
                  className="text-sm text-obsidian-300 transition hover:text-gold"
                >
                  {l}
                </a>
              ))}
            </div>
          </div>

          <div>
            <p className="font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
              Categories
            </p>
            <div className="mt-4 flex flex-col gap-3">
              {['Handbags', 'Watches', 'Jewelry', 'Collector Apparel'].map((l) => (
                <span key={l} className="text-sm text-obsidian-300">
                  {l}
                </span>
              ))}
            </div>
          </div>

          <div>
            <p className="font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
              Contact
            </p>
            <div className="mt-4 flex flex-col gap-3 text-sm text-obsidian-300">
              <span className="flex items-center gap-2.5">
                <Mail size={14} className="text-gold" /> concierge@elitevault.com
              </span>
              <span className="flex items-center gap-2.5">
                <Phone size={14} className="text-gold" /> +1 (555) 012-3456
              </span>
              <span className="flex items-center gap-2.5">
                <MapPin size={14} className="text-gold" /> By appointment — Global
              </span>
            </div>
          </div>
        </div>

        <div className="hairline-divider my-10" />

        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
          <p className="font-mono text-[10px] uppercase tracking-wider text-obsidian-500">
            © {new Date().getFullYear()} EliteVault Logistics. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="font-mono text-[10px] uppercase tracking-wider text-obsidian-500 hover:text-gold">
              Privacy
            </a>
            <a href="#" className="font-mono text-[10px] uppercase tracking-wider text-obsidian-500 hover:text-gold">
              Terms
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
