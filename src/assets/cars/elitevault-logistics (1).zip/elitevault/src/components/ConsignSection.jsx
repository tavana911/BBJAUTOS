import { PackageCheck, ShieldCheck, Gavel, Wallet } from 'lucide-react'
import ConsignForm from './ConsignForm'

const PROCESS = [
  {
    icon: PackageCheck,
    title: 'Submit & Ship',
    copy: 'Complete the intake form and send your item via our insured white-glove courier.',
  },
  {
    icon: ShieldCheck,
    title: 'Authenticate',
    copy: 'Our specialists inspect and authenticate every detail before listing.',
  },
  {
    icon: Gavel,
    title: 'List & Sell',
    copy: 'Your piece is presented to our VIP network of verified collectors.',
  },
  {
    icon: Wallet,
    title: 'Get Paid',
    copy: 'Funds are released to you promptly once the sale is finalized.',
  },
]

export default function ConsignSection() {
  return (
    <section id="consign" className="relative border-t border-hairline py-24 sm:py-32">
      <div className="container-vault">
        <div className="mx-auto mb-16 max-w-2xl text-center">
          <p className="eyebrow">White-Glove Process</p>
          <h2 className="mt-3 font-display text-3xl font-light text-ivory sm:text-4xl">
            Consign With Confidence
          </h2>
          <p className="mt-4 text-sm text-obsidian-300 sm:text-base">
            From submission to payout, your asset is tracked, insured, and handled by
            specialists at every stage.
          </p>
        </div>

        <div className="mx-auto mb-20 grid max-w-4xl grid-cols-2 gap-6 lg:grid-cols-4">
          {PROCESS.map((step) => (
            <div key={step.title} className="text-center">
              <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full border border-gold/40 bg-gold/5 text-gold">
                <step.icon size={19} />
              </div>
              <h3 className="font-display text-base text-ivory">{step.title}</h3>
              <p className="mt-2 text-xs leading-relaxed text-obsidian-400">{step.copy}</p>
            </div>
          ))}
        </div>

        <ConsignForm />
      </div>
    </section>
  )
}
