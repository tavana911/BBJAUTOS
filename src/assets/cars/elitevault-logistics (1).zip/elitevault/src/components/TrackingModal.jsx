import { AnimatePresence, motion } from 'framer-motion'
import { X, PackageSearch, ShieldCheck, CircleAlert } from 'lucide-react'
import StatusPipeline from './StatusPipeline'
import { STATUS_STEPS } from '../lib/consignments'

function formatCurrency(value) {
  if (value === null || value === undefined) return '—'
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(value)
}

function formatDate(iso) {
  if (!iso) return '—'
  return new Intl.DateTimeFormat('en-US', {
    dateStyle: 'medium',
  }).format(new Date(iso))
}

export default function TrackingModal({ open, onClose, loading, consignment, error, queriedCode }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[70] flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="absolute inset-0 bg-obsidian-950/80 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.98 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="panel shadow-panel relative z-10 w-full max-w-2xl overflow-hidden rounded-lg"
          >
            <div className="flex items-center justify-between border-b border-hairline px-6 py-5">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-full border border-gold/40 bg-gold/10 text-gold">
                  <PackageSearch size={16} />
                </div>
                <div>
                  <p className="eyebrow">Consignment Status</p>
                  <p className="font-display text-lg text-ivory">Asset Tracking</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="rounded-full p-2 text-obsidian-300 transition hover:bg-obsidian-800 hover:text-ivory"
                aria-label="Close tracking result"
              >
                <X size={18} />
              </button>
            </div>

            <div className="px-6 py-6">
              {loading && (
                <div className="flex flex-col items-center gap-3 py-10 text-obsidian-300">
                  <div className="h-8 w-8 animate-spin rounded-full border-2 border-hairline border-t-gold" />
                  <p className="font-mono text-xs uppercase tracking-wider">
                    Retrieving vault record…
                  </p>
                </div>
              )}

              {!loading && error && (
                <div className="flex flex-col items-center gap-3 py-10 text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full border border-red-900/50 bg-red-950/30 text-red-400">
                    <CircleAlert size={20} />
                  </div>
                  <p className="font-display text-lg text-ivory">No record found</p>
                  <p className="max-w-sm text-sm text-obsidian-300">
                    We couldn't find a consignment matching{' '}
                    <span className="font-mono text-gold">{queriedCode}</span>. Double-check
                    your tracking code or reach out to your VIP Concierge for assistance.
                  </p>
                  {error.demo && (
                    <p className="mt-1 max-w-sm text-xs text-obsidian-400">
                      Demo mode — try{' '}
                      <span className="font-mono text-gold">EVL-89234</span>,{' '}
                      <span className="font-mono text-gold">EVL-40217</span>, or{' '}
                      <span className="font-mono text-gold">EVL-10056</span>.
                    </p>
                  )}
                </div>
              )}

              {!loading && !error && consignment && (
                <div className="space-y-8">
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <p className="font-mono text-xs tracking-widest text-gold">
                        {consignment.tracking_number}
                      </p>
                      <h3 className="mt-1 font-display text-xl text-ivory">
                        {consignment.item_title}
                      </h3>
                      <p className="mt-1 text-sm text-obsidian-300">{consignment.category}</p>
                    </div>
                    <div className="flex items-center gap-2 rounded-full border border-gold/30 bg-gold/5 px-3 py-1.5">
                      <ShieldCheck size={14} className="text-gold" />
                      <span className="font-mono text-[10px] uppercase tracking-wider text-gold">
                        {STATUS_STEPS.find((s) => s.key === consignment.status)?.label ??
                          consignment.status}
                      </span>
                    </div>
                  </div>

                  <StatusPipeline status={consignment.status} />

                  <div className="hairline-divider" />

                  <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                    <div>
                      <p className="font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
                        Client
                      </p>
                      <p className="mt-1 text-sm text-ivory">{consignment.client_name}</p>
                    </div>
                    <div>
                      <p className="font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
                        Est. Value
                      </p>
                      <p className="mt-1 text-sm text-ivory">
                        {formatCurrency(consignment.estimated_value)}
                      </p>
                    </div>
                    <div>
                      <p className="font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
                        Received
                      </p>
                      <p className="mt-1 text-sm text-ivory">
                        {formatDate(consignment.created_at)}
                      </p>
                    </div>
                    <div>
                      <p className="font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
                        Last Update
                      </p>
                      <p className="mt-1 text-sm text-ivory">
                        {formatDate(consignment.updated_at)}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
