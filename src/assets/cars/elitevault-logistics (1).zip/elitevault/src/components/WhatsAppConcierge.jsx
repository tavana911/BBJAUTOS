import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  MessageCircle,
  X,
  ShieldCheck,
  PackageSearch,
  Gem,
  CircleHelp,
  ArrowUpRight,
} from 'lucide-react'

// TODO: replace with EliteVault's real WhatsApp Business number (international format, no + or spaces)
const WHATSAPP_NUMBER = '15550123456'

const PRESETS = [
  {
    icon: Gem,
    label: 'Consign an Item',
    message:
      'Hello EliteVault, I would like to inquire about consigning an item with your VIP service.',
  },
  {
    icon: PackageSearch,
    label: 'Track Package',
    message: 'Hello EliteVault, I would like an update on the status of my consignment.',
  },
  {
    icon: CircleHelp,
    label: 'General Inquiry',
    message: 'Hello EliteVault, I have a general question about your consignment service.',
  },
]

function buildWhatsAppLink(message) {
  const encoded = encodeURIComponent(message)
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encoded}`
}

export default function WhatsAppConcierge({ open, onOpenChange }) {
  const [customMessage, setCustomMessage] = useState('')

  return (
    <div className="fixed bottom-5 right-5 z-[80] sm:bottom-7 sm:right-7">
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.96 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="panel shadow-panel mb-4 w-[92vw] max-w-sm overflow-hidden rounded-lg"
          >
            <div className="flex items-center justify-between border-b border-hairline bg-gradient-to-r from-obsidian-900 to-obsidian-800 px-5 py-4">
              <div className="flex items-center gap-3">
                <div className="relative flex h-10 w-10 items-center justify-center rounded-full border border-gold/50 bg-gold/10 text-gold">
                  <ShieldCheck size={17} />
                  <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-obsidian-900 bg-emerald-400" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-ivory">EliteVault VIP Concierge</p>
                  <p className="font-mono text-[10px] uppercase tracking-wider text-emerald-400">
                    Online now
                  </p>
                </div>
              </div>
              <button
                onClick={() => onOpenChange(false)}
                className="rounded-full p-1.5 text-obsidian-300 transition hover:bg-obsidian-800 hover:text-ivory"
                aria-label="Close concierge chat"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-4 px-5 py-5">
              <div className="rounded-md border border-hairline bg-obsidian-900/60 px-4 py-3">
                <p className="text-sm leading-relaxed text-obsidian-200">
                  Good day. I'm your dedicated EliteVault concierge — how may I assist with
                  your consignment today?
                </p>
              </div>

              <div>
                <p className="mb-2 font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
                  Quick Actions
                </p>
                <div className="flex flex-col gap-2">
                  {PRESETS.map((preset) => (
                    <a
                      key={preset.label}
                      href={buildWhatsAppLink(preset.message)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group flex items-center justify-between rounded-md border border-hairline px-3.5 py-2.5 text-sm text-ivory transition hover:border-gold/50 hover:bg-gold/5"
                    >
                      <span className="flex items-center gap-2.5">
                        <preset.icon size={15} className="text-gold" />
                        {preset.label}
                      </span>
                      <ArrowUpRight
                        size={14}
                        className="text-obsidian-400 transition group-hover:text-gold"
                      />
                    </a>
                  ))}
                </div>
              </div>

              <div>
                <p className="mb-2 font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
                  Or write your own message
                </p>
                <textarea
                  value={customMessage}
                  onChange={(e) => setCustomMessage(e.target.value)}
                  rows={2}
                  placeholder="Type a message to send via WhatsApp…"
                  className="w-full resize-none rounded-md border border-hairline bg-obsidian-900/60 px-3.5 py-2.5 text-sm text-ivory placeholder:text-obsidian-500 focus:border-gold/50 focus:outline-none"
                />
                <a
                  href={buildWhatsAppLink(
                    customMessage.trim() || 'Hello EliteVault, I would like to inquire about...'
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-gold mt-3 w-full !py-2.5 text-xs"
                >
                  Continue on WhatsApp
                  <ArrowUpRight size={14} />
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={() => onOpenChange(!open)}
        whileTap={{ scale: 0.94 }}
        className="flex h-14 w-14 items-center justify-center rounded-full border border-gold/40 bg-obsidian-900 text-gold shadow-gold transition hover:bg-obsidian-800 sm:h-16 sm:w-16"
        aria-label="Open VIP Concierge live chat"
      >
        {open ? <X size={22} /> : <MessageCircle size={24} />}
      </motion.button>
    </div>
  )
}
