import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Menu, X, MessageCircleMore, ShieldCheck } from 'lucide-react'

const LINKS = [
  { label: 'Track', href: '#track' },
  { label: 'Consign', href: '#consign' },
  { label: 'Catalog', href: '#catalog' },
  { label: 'Contact', href: '#contact' },
]

export default function Navbar({ onOpenConcierge }) {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={[
        'fixed inset-x-0 top-0 z-50 transition-all duration-500',
        scrolled
          ? 'border-b border-hairline bg-obsidian-950/85 backdrop-blur-md'
          : 'border-b border-transparent bg-transparent',
      ].join(' ')}
    >
      <div className="container-vault flex h-16 items-center justify-between sm:h-20">
        <a href="#top" className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-full border border-gold/50 text-gold">
            <ShieldCheck size={15} />
          </span>
          <span className="font-display text-lg tracking-wide text-ivory">
            Elite<span className="text-gold">Vault</span>
          </span>
        </a>

        <nav className="hidden items-center gap-9 lg:flex">
          {LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="font-mono text-[11px] uppercase tracking-[0.2em] text-obsidian-300 transition hover:text-gold"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <button onClick={onOpenConcierge} className="btn-ghost !px-4 !py-2.5 text-xs">
            <MessageCircleMore size={15} />
            Concierge
          </button>
          <a href="#consign" className="btn-gold !px-4 !py-2.5 text-xs">
            Consign With Us
          </a>
        </div>

        <button
          className="rounded-sm p-2 text-ivory lg:hidden"
          onClick={() => setMobileOpen((v) => !v)}
          aria-label="Toggle navigation menu"
        >
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {mobileOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="border-t border-hairline bg-obsidian-950 px-5 pb-6 pt-4 lg:hidden"
        >
          <div className="flex flex-col gap-4">
            {LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="font-mono text-xs uppercase tracking-[0.2em] text-obsidian-300"
              >
                {link.label}
              </a>
            ))}
            <div className="mt-2 flex flex-col gap-3">
              <button
                onClick={() => {
                  setMobileOpen(false)
                  onOpenConcierge()
                }}
                className="btn-ghost w-full"
              >
                <MessageCircleMore size={15} />
                Concierge
              </button>
              <a href="#consign" onClick={() => setMobileOpen(false)} className="btn-gold w-full">
                Consign With Us
              </a>
            </div>
          </div>
        </motion.div>
      )}
    </header>
  )
}
