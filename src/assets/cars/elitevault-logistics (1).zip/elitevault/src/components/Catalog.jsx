import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Gem, Watch, ShoppingBag, Shirt, LayoutGrid } from 'lucide-react'
import { getProducts } from '../lib/products'

const CATEGORIES = [
  { label: 'All', icon: LayoutGrid, value: null },
  { label: 'High-End Handbags', icon: ShoppingBag, value: 'High-End Handbags' },
  { label: 'Luxury Watches', icon: Watch, value: 'Luxury Watches' },
  { label: 'Fine Jewelry', icon: Gem, value: 'Fine Jewelry' },
  { label: 'Collector Apparel', icon: Shirt, value: 'Collector Apparel' },
]

const CONDITION_STYLES = {
  Pristine: 'border-gold/50 bg-gold/10 text-gold',
  'Like New': 'border-silver/40 bg-silver/10 text-silver-light',
  Certified: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-400',
}

function formatCurrency(value) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(value)
}

export default function Catalog() {
  const [active, setActive] = useState(null)
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let ignore = false
    setLoading(true)
    getProducts({ category: active }).then(({ data }) => {
      if (!ignore) {
        setProducts(data ?? [])
        setLoading(false)
      }
    })
    return () => {
      ignore = true
    }
  }, [active])

  return (
    <section id="catalog" className="relative py-24 sm:py-32">
      <div className="container-vault">
        <div className="mb-12 flex flex-col gap-6 sm:mb-16 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="eyebrow">The Collection</p>
            <h2 className="mt-3 max-w-xl font-display text-3xl font-light text-ivory sm:text-4xl">
              Curated for the Discerning
            </h2>
          </div>
          <p className="max-w-sm text-sm text-obsidian-300">
            Every piece independently authenticated and graded before it reaches the
            catalog — no exceptions.
          </p>
        </div>

        <div className="mb-10 flex flex-wrap gap-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.label}
              onClick={() => setActive(cat.value)}
              className={[
                'flex items-center gap-2 rounded-full border px-4 py-2 font-mono text-[11px] uppercase tracking-wider transition-all',
                active === cat.value
                  ? 'border-gold bg-gold text-obsidian-950'
                  : 'border-hairline text-obsidian-300 hover:border-gold/50 hover:text-gold',
              ].join(' ')}
            >
              <cat.icon size={13} />
              {cat.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-80 animate-pulse rounded-md border border-hairline bg-obsidian-800/50" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {products.map((item, i) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
                className="group overflow-hidden rounded-md border border-hairline bg-panel/60 transition-all duration-500 hover:border-gold/40 hover:shadow-gold"
              >
                <div className="relative aspect-[4/3] overflow-hidden bg-obsidian-800">
                  <img
                    src={item.image_url}
                    alt={item.title}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-obsidian-950/70 via-transparent to-transparent" />
                  <span
                    className={[
                      'absolute left-3 top-3 rounded-full border px-2.5 py-1 font-mono text-[9px] uppercase tracking-wider backdrop-blur-sm',
                      CONDITION_STYLES[item.condition] ??
                        'border-hairline bg-obsidian-900/70 text-obsidian-300',
                    ].join(' ')}
                  >
                    {item.condition}
                  </span>
                </div>
                <div className="p-5">
                  <p className="font-mono text-[10px] uppercase tracking-wider text-obsidian-400">
                    {item.category}
                  </p>
                  <h3 className="mt-1.5 font-display text-base text-ivory">{item.title}</h3>
                  <div className="mt-4 flex items-center justify-between">
                    <p className="font-display text-lg text-gold">
                      {formatCurrency(item.price)}
                    </p>
                    <button className="font-mono text-[10px] uppercase tracking-wider text-obsidian-300 transition group-hover:text-gold">
                      Enquire →
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
