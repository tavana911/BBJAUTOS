import { useState } from 'react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import Catalog from './components/Catalog'
import ConsignSection from './components/ConsignSection'
import Footer from './components/Footer'
import WhatsAppConcierge from './components/WhatsAppConcierge'
import { isSupabaseConfigured } from './lib/consignments'

export default function App() {
  const [conciergeOpen, setConciergeOpen] = useState(false)

  return (
    <div className="min-h-screen bg-obsidian-950 font-body text-ivory">
      {!isSupabaseConfigured && (
        <div className="bg-gold/10 px-4 py-2 text-center font-mono text-[10px] uppercase tracking-wider text-gold">
          Demo mode — connect Supabase in .env to enable live data (see README)
        </div>
      )}

      <Navbar onOpenConcierge={() => setConciergeOpen(true)} />
      <main>
        <Hero />
        <Catalog />
        <ConsignSection />
      </main>
      <Footer />

      <WhatsAppConcierge open={conciergeOpen} onOpenChange={setConciergeOpen} />
    </div>
  )
}
