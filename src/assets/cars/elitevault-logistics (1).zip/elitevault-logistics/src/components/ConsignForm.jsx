import { useState } from 'react'
import { motion } from 'framer-motion'
import { UploadCloud, CheckCircle2, Loader2 } from 'lucide-react'
import { supabase, isSupabaseConfigured } from '../lib/supabaseClient'
import { CATEGORIES } from '../data/mockData'

const initialForm = {
  client_name: '',
  client_email: '',
  item_title: '',
  category: CATEGORIES[0].id,
  estimated_value: '',
}

function generateTrackingNumber() {
  const n = Math.floor(10000 + Math.random() * 90000)
  return `EVL-${n}`
}

export default function ConsignForm() {
  const [form, setForm] = useState(initialForm)
  const [file, setFile] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [result, setResult] = useState(null) // { trackingNumber } | null
  const [error, setError] = useState(null)

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitting(true)
    setError(null)

    try {
      const trackingNumber = generateTrackingNumber()

      if (isSupabaseConfigured) {
        let imagePath = null

        if (file) {
          const ext = file.name.split('.').pop()
          const path = `intake/${trackingNumber}-${Date.now()}.${ext}`
          const { error: uploadError } = await supabase.storage
            .from('consignment-images')
            .upload(path, file)
          if (uploadError) throw uploadError
          imagePath = path
        }

        const { error: insertError } = await supabase.from('consignments').insert({
          tracking_number: trackingNumber,
          client_name: form.client_name,
          client_email: form.client_email,
          item_title: form.item_title,
          category: form.category,
          estimated_value: form.estimated_value ? Number(form.estimated_value) : null,
          status: 'pending',
          image_path: imagePath,
        })
        if (insertError) throw insertError
      } else {
        // Demo mode — simulate latency, no persistence
        await new Promise((r) => setTimeout(r, 900))
      }

      setResult({ trackingNumber })
      setForm(initialForm)
      setFile(null)
    } catch (err) {
      setError(err.message || 'Something went wrong. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  if (result) {
    return (
      <div className="rounded-2xl border border-gold/30 bg-obsidian-2 p-8 text-center">
        <CheckCircle2 className="mx-auto h-10 w-10 text-gold" strokeWidth={1.3} />
        <h3 className="mt-4 font-display text-2xl text-ink">Submission received</h3>
        <p className="mx-auto mt-2 max-w-sm text-sm text-slate">
          Your item has entered the vault pipeline. Save your tracking number
          to follow its progress.
        </p>
        <div className="mx-auto mt-5 inline-block rounded-xl border border-gold/30 bg-obsidian-3 px-6 py-3 font-mono text-lg text-gold-soft">
          {result.trackingNumber}
        </div>
        <button
          onClick={() => setResult(null)}
          className="mt-6 block w-full text-sm text-slate underline decoration-line underline-offset-4 hover:text-gold-soft"
        >
          Submit another item
        </button>
      </div>
    )
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="rounded-2xl border hairline bg-obsidian-2 p-6 sm:p-8"
    >
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Full name">
          <input
            required
            value={form.client_name}
            onChange={(e) => update('client_name', e.target.value)}
            className="vip-input"
            placeholder="Jordan Kensington"
          />
        </Field>
        <Field label="Email">
          <input
            required
            type="email"
            value={form.client_email}
            onChange={(e) => update('client_email', e.target.value)}
            className="vip-input"
            placeholder="you@example.com"
          />
        </Field>
        <Field label="Item title" full>
          <input
            required
            value={form.item_title}
            onChange={(e) => update('item_title', e.target.value)}
            className="vip-input"
            placeholder="Hermès Birkin 30 Togo Gold Hardware"
          />
        </Field>
        <Field label="Category">
          <select
            value={form.category}
            onChange={(e) => update('category', e.target.value)}
            className="vip-input"
          >
            {CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Estimated value (USD)">
          <input
            type="number"
            min="0"
            value={form.estimated_value}
            onChange={(e) => update('estimated_value', e.target.value)}
            className="vip-input"
            placeholder="24500"
          />
        </Field>

        <Field label="Item photo" full>
          <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-dashed hairline bg-obsidian-3 px-4 py-4 text-sm text-slate transition-colors hover:border-gold/50">
            <UploadCloud className="h-4 w-4 shrink-0" strokeWidth={1.5} />
            <span className="truncate">
              {file ? file.name : 'Click to upload a photo (JPG, PNG)'}
            </span>
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
            />
          </label>
        </Field>
      </div>

      {error && (
        <p className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-2.5 text-sm text-red-300">
          {error}
        </p>
      )}

      {!isSupabaseConfigured && (
        <p className="mt-4 text-xs text-slate-dim">
          Running in demo mode — connect Supabase to persist submissions and
          uploaded images.
        </p>
      )}

      <motion.button
        whileTap={{ scale: 0.98 }}
        type="submit"
        disabled={submitting}
        className="mt-7 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#e8d9b5] via-[#c9a961] to-[#8a7444] px-6 py-3.5 text-sm font-semibold text-obsidian transition-opacity disabled:opacity-60 vip-focus"
      >
        {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
        {submitting ? 'Submitting…' : 'Submit for Consignment'}
      </motion.button>
    </form>
  )
}

function Field({ label, children, full }) {
  return (
    <label className={`block ${full ? 'sm:col-span-2' : ''}`}>
      <span className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-slate">
        {label}
      </span>
      {children}
    </label>
  )
}
