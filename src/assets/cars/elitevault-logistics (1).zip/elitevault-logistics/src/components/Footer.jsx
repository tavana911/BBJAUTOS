import { ShieldCheck, Mail, MapPin, Phone } from 'lucide-react'

export default function Footer() {
  return (
    <footer id="contact" className="border-t hairline bg-obsidian-2">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-gold" strokeWidth={1.5} />
              <span className="font-display text-lg text-ink">
                Elite<span className="gold-gradient-text">Vault</span>
              </span>
            </div>
            <p className="mt-3 text-sm text-slate">
              White-glove VIP consignment and secure asset tracking.
            </p>
          </div>

          <div>
            <div className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-dim">
              Navigate
            </div>
            <ul className="space-y-2 text-sm text-slate">
              <li><a href="#track" className="hover:text-gold-soft">Tracking</a></li>
              <li><a href="#consign" className="hover:text-gold-soft">Consign</a></li>
              <li><a href="#catalog" className="hover:text-gold-soft">Catalog</a></li>
            </ul>
          </div>

          <div>
            <div className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-dim">
              Categories
            </div>
            <ul className="space-y-2 text-sm text-slate">
              <li>High-End Handbags</li>
              <li>Luxury Watches</li>
              <li>Fine Jewelry</li>
              <li>Collector Apparel</li>
            </ul>
          </div>

          <div>
            <div className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-dim">
              Contact
            </div>
            <ul className="space-y-2.5 text-sm text-slate">
              <li className="flex items-center gap-2">
                <Mail className="h-3.5 w-3.5 shrink-0" /> concierge@elitevault.co
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-3.5 w-3.5 shrink-0" /> +1 (555) 123-4567
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-3.5 w-3.5 shrink-0" /> By appointment only
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t hairline pt-8 text-xs text-slate-dim sm:flex-row">
          <span>© {new Date().getFullYear()} EliteVault Logistics. All rights reserved.</span>
          <span>Every asset insured, authenticated, and discreetly handled.</span>
        </div>
      </div>
    </footer>
  )
}
