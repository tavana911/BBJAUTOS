import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, ShieldCheck, MessageCircle } from 'lucide-react'

const LINKS = [
  { href: '#track', label: 'Tracking' },
  { href: '#consign', label: 'Consign' },
  { href: '#catalog', label: 'Catalog' },
  { href: '#contact', label: 'Contact' },
]

export default function Navbar({ onOpenConcierge }) {
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-40 border-b hairline bg-obsidian/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
        <a href="#top" className="flex items-center gap-2.5">
          <ShieldCheck className="h-6 w-6 text-gold" strokeWidth={1.5} />
          <span className="font-display text-xl tracking-wide text-ink">
            Elite<span className="gold-gradient-text">Vault</span>
          </span>
        </a>

        <nav className="hidden items-center gap-9 md:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm font-medium tracking-wide text-slate transition-colors hover:text-gold-soft vip-focus"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <button
            onClick={onOpenConcierge}
            className="flex items-center gap-2 rounded-full border hairline px-4 py-2 text-sm font-medium text-ink transition-colors hover:border-gold hover:text-gold-soft vip-focus"
          >
            <MessageCircle className="h-4 w-4" strokeWidth={1.5} />
            VIP Concierge
          </button>
          <a
            href="#consign"
            className="rounded-full bg-gradient-to-r from-[#e8d9b5] via-[#c9a961] to-[#8a7444] px-5 py-2 text-sm font-semibold text-obsidian transition-transform hover:scale-[1.03] vip-focus"
          >
            Consign With Us
          </a>
        </div>

        <button
          className="text-ink md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="overflow-hidden border-t hairline md:hidden"
          >
            <div className="flex flex-col gap-1 px-6 py-4">
              {LINKS.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="rounded-lg px-3 py-3 text-sm font-medium text-ink hover:bg-obsidian-3"
                >
                  {l.label}
                </a>
              ))}
              <button
                onClick={() => {
                  setOpen(false)
                  onOpenConcierge()
                }}
                className="mt-2 flex items-center justify-center gap-2 rounded-full border hairline px-4 py-3 text-sm font-medium text-ink"
              >
                <MessageCircle className="h-4 w-4" /> VIP Concierge
              </button>
              <a
                href="#consign"
                onClick={() => setOpen(false)}
                className="mt-1 rounded-full bg-gradient-to-r from-[#e8d9b5] via-[#c9a961] to-[#8a7444] px-4 py-3 text-center text-sm font-semibold text-obsidian"
              >
                Consign With Us
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}
