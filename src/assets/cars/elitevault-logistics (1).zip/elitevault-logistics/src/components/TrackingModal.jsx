import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, CheckCircle2, Circle, PackageSearch } from 'lucide-react'
import { supabase, isSupabaseConfigured } from '../lib/supabaseClient'
import { MOCK_CONSIGNMENTS } from '../data/mockData'
import { PIPELINE_STAGES, stageIndex } from '../data/pipeline'
import VaultDial from './VaultDial'

export default function TrackingModal({ code, onClose }) {
  const [status, setStatus] = useState('loading') // loading | found | not-found
  const [record, setRecord] = useState(null)

  useEffect(() => {
    if (!code) return
    let cancelled = false

    async function lookup() {
      setStatus('loading')

      if (isSupabaseConfigured) {
        const { data, error } = await supabase
          .from('consignments')
          .select('*')
          .eq('tracking_number', code.toUpperCase())
          .maybeSingle()

        if (cancelled) return
        if (error || !data) {
          setStatus('not-found')
        } else {
          setRecord(data)
          setStatus('found')
        }
        return
      }

      // Demo mode fallback
      await new Promise((r) => setTimeout(r, 500))
      if (cancelled) return
      const found = MOCK_CONSIGNMENTS[code.toUpperCase()]
      if (found) {
        setRecord(found)
        setStatus('found')
      } else {
        setStatus('not-found')
      }
    }

    lookup()
    return () => {
      cancelled = true
    }
  }, [code])

  const currentIndex = record ? stageIndex(record.status) : -1
  const progress = currentIndex >= 0 ? (currentIndex + 1) / PIPELINE_STAGES.length : 0

  return (
    <AnimatePresence>
      {code && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-2xl overflow-hidden rounded-2xl border hairline bg-obsidian-2 shadow-2xl"
          >
            <button
              onClick={onClose}
              className="absolute right-4 top-4 z-10 rounded-full border hairline p-2 text-slate transition-colors hover:text-gold-soft vip-focus"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="max-h-[85vh] overflow-y-auto p-6 sm:p-8">
              <div className="mb-1 font-mono text-xs uppercase tracking-[0.25em] text-gold-dim">
                Consignment status
              </div>
              <h3 className="font-display text-2xl text-ink">
                {code.toUpperCase()}
              </h3>

              {status === 'loading' && (
                <div className="mt-10 flex flex-col items-center gap-4 py-6">
                  <VaultDial size={160} progress={0.15} />
                  <p className="text-sm text-slate">Retrieving vault record…</p>
                </div>
              )}

              {status === 'not-found' && (
                <div className="mt-10 flex flex-col items-center gap-4 py-6 text-center">
                  <PackageSearch className="h-10 w-10 text-slate-dim" strokeWidth={1.2} />
                  <p className="max-w-xs text-sm text-slate">
                    We couldn't find a consignment with that tracking number.
                    Double-check the code or reach out to your concierge.
                  </p>
                </div>
              )}

              {status === 'found' && record && (
                <div className="mt-6">
                  <div className="grid gap-6 sm:grid-cols-[auto_1fr] sm:items-center">
                    <VaultDial size={140} progress={progress} />
                    <div>
                      <div className="text-lg font-medium text-ink">
                        {record.item_title}
                      </div>
                      <div className="mt-1 text-sm text-slate">
                        {record.category}
                      </div>
                      {record.estimated_value && (
                        <div className="mt-3 font-mono text-sm text-gold-soft">
                          Est. value ${Number(record.estimated_value).toLocaleString()}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="mt-10 space-y-0">
                    {PIPELINE_STAGES.map((stage, i) => {
                      const done = i <= currentIndex
                      const isLast = i === PIPELINE_STAGES.length - 1
                      return (
                        <div key={stage.key} className="flex gap-4">
                          <div className="flex flex-col items-center">
                            {done ? (
                              <CheckCircle2
                                className="h-5 w-5 text-gold"
                                strokeWidth={1.5}
                              />
                            ) : (
                              <Circle className="h-5 w-5 text-slate-dim" strokeWidth={1.5} />
                            )}
                            {!isLast && (
                              <div
                                className={`w-px flex-1 ${
                                  i < currentIndex ? 'bg-gold' : 'bg-line'
                                }`}
                                style={{ minHeight: 28 }}
                              />
                            )}
                          </div>
                          <div className={`pb-7 ${done ? 'text-ink' : 'text-slate-dim'}`}>
                            <div className="text-sm font-medium">{stage.label}</div>
                            {i === currentIndex && (
                              <div className="mt-0.5 text-xs text-gold-dim">
                                Current stage
                              </div>
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
