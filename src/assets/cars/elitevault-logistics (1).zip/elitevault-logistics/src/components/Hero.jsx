import { useState } from 'react'
import { motion } from 'framer-motion'
import { Search, ArrowRight } from 'lucide-react'
import VaultDial from './VaultDial'

export default function Hero({ onTrack }) {
  const [code, setCode] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    if (code.trim()) onTrack(code.trim())
  }

  return (
    <section id="top" className="relative overflow-hidden border-b hairline">
      <span id="track" className="absolute -top-20" aria-hidden="true" />
      <div className="pointer-events-none absolute right-[-120px] top-[-60px] opacity-40 md:right-[-40px] md:opacity-70">
        <VaultDial size={560} ambient />
      </div>

      <div className="relative mx-auto max-w-7xl px-6 pb-20 pt-16 lg:px-10 lg:pb-28 lg:pt-24">
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-5 font-mono text-xs uppercase tracking-[0.3em] text-gold-dim"
        >
          By-appointment consignment &amp; secure asset logistics
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.05 }}
          className="max-w-3xl font-display text-5xl font-light leading-[1.05] text-ink sm:text-6xl lg:text-7xl"
        >
          Elite<span className="gold-gradient-text">Vault</span> Logistics
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.12 }}
          className="mt-6 max-w-xl text-lg text-slate"
        >
          White-glove VIP consignment and secure asset tracking — from intake
          to authentication to payout, watched over at every stage.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-10 max-w-xl"
        >
          <form
            onSubmit={handleSubmit}
            className="flex flex-col gap-3 rounded-2xl border hairline bg-obsidian-2/80 p-2 shadow-2xl shadow-black/40 sm:flex-row"
          >
            <div className="flex flex-1 items-center gap-3 rounded-xl bg-obsidian-3 px-4 py-3.5">
              <Search className="h-4 w-4 shrink-0 text-slate" strokeWidth={1.5} />
              <input
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Track your consignment — e.g. EVL-89234"
                className="w-full bg-transparent font-mono text-sm text-ink placeholder:text-slate-dim focus:outline-none"
              />
            </div>
            <button
              type="submit"
              className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#e8d9b5] via-[#c9a961] to-[#8a7444] px-6 py-3.5 text-sm font-semibold text-obsidian transition-transform hover:scale-[1.02] vip-focus"
            >
              Track Item
              <ArrowRight className="h-4 w-4" strokeWidth={2} />
            </button>
          </form>
          <p className="mt-3 text-xs text-slate-dim">
            Try a demo code: <span className="font-mono text-gold-dim">EVL-89234</span>,{' '}
            <span className="font-mono text-gold-dim">EVL-10042</span>, or{' '}
            <span className="font-mono text-gold-dim">EVL-55501</span>
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.28 }}
          className="mt-14 flex flex-wrap gap-x-10 gap-y-4"
        >
          {[
            ['White-Glove', 'Insured pickup & handling'],
            ['Authenticated', 'Third-party verified experts'],
            ['Discreet', 'Confidential client handling'],
          ].map(([title, sub]) => (
            <div key={title} className="border-l hairline pl-4">
              <div className="text-sm font-semibold text-ink">{title}</div>
              <div className="text-xs text-slate-dim">{sub}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
