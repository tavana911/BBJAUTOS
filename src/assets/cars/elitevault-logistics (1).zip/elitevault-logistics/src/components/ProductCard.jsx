import { motion } from 'framer-motion'

const BADGE_STYLES = {
  Pristine: 'bg-gold/15 text-gold-soft border-gold/30',
  'Like New': 'bg-platinum/10 text-platinum border-platinum/25',
  Certified: 'bg-emerald-400/10 text-emerald-300 border-emerald-400/25',
}

export default function ProductCard({ product }) {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className="group overflow-hidden rounded-2xl border hairline bg-obsidian-2"
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-obsidian-3">
        <img
          src={product.image_url}
          alt={product.title}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <span
          className={`absolute left-3 top-3 rounded-full border px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider backdrop-blur-sm ${
            BADGE_STYLES[product.condition] || 'bg-obsidian-3 text-slate border-line'
          }`}
        >
          {product.condition}
        </span>
      </div>
      <div className="p-4">
        <div className="line-clamp-2 text-sm font-medium text-ink">
          {product.title}
        </div>
        <div className="mt-2 flex items-center justify-between">
          <span className="font-mono text-sm text-gold-soft">
            ${Number(product.price).toLocaleString()}
          </span>
          {!product.is_available && (
            <span className="text-xs text-slate-dim">Sold</span>
          )}
        </div>
      </div>
    </motion.div>
  )
}
