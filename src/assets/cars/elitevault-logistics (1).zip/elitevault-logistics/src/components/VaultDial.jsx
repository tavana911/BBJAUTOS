import { motion } from 'framer-motion'

// The signature motif: a bank-vault combination dial. In the hero it turns
// slowly as pure ambience. On the tracking page the same rings become a
// literal progress dial — the gold arc sweeps to the consignment's stage.
export default function VaultDial({
  size = 420,
  progress = 0, // 0..1
  ambient = false,
  className = '',
}) {
  const r1 = size * 0.46
  const r2 = size * 0.36
  const r3 = size * 0.26
  const center = size / 2
  const circumference = 2 * Math.PI * r1
  const dash = circumference * progress

  const ticks = Array.from({ length: 60 })

  return (
    <svg
      viewBox={`0 0 ${size} ${size}`}
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label={ambient ? undefined : `Progress dial, ${Math.round(progress * 100)} percent`}
    >
      <circle cx={center} cy={center} r={r1} fill="none" stroke="#22252c" strokeWidth={1} />
      <circle cx={center} cy={center} r={r2} fill="none" stroke="#1a1d23" strokeWidth={1} />
      <circle cx={center} cy={center} r={r3} fill="none" stroke="#1a1d23" strokeWidth={1} />

      {ticks.map((_, i) => {
        const angle = (i / ticks.length) * Math.PI * 2
        const long = i % 5 === 0
        const inner = long ? r1 - 14 : r1 - 7
        const x1 = center + Math.cos(angle) * r1
        const y1 = center + Math.sin(angle) * r1
        const x2 = center + Math.cos(angle) * inner
        const y2 = center + Math.sin(angle) * inner
        return (
          <line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke={long ? '#8a7444' : '#26292f'}
            strokeWidth={long ? 1.5 : 1}
          />
        )
      })}

      {!ambient && (
        <g transform={`rotate(-90 ${center} ${center})`}>
          <circle
            cx={center}
            cy={center}
            r={r1}
            fill="none"
            stroke="#c9a961"
            strokeWidth={2.5}
            strokeLinecap="round"
            strokeDasharray={`${dash} ${circumference}`}
          />
        </g>
      )}

      {ambient && (
        <motion.g
          animate={{ rotate: 360 }}
          transition={{ duration: 90, repeat: Infinity, ease: 'linear' }}
          style={{ transformOrigin: `${center}px ${center}px` }}
        >
          <circle
            cx={center}
            cy={center}
            r={r1}
            fill="none"
            stroke="#c9a961"
            strokeWidth={1.5}
            strokeDasharray="2 14"
            opacity={0.6}
          />
        </motion.g>
      )}

      <circle cx={center} cy={center} r={r3} fill="none" stroke="#c9a961" strokeWidth={1} opacity={0.5} />
    </svg>
  )
}
