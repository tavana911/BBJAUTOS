import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { MessageCircle, X, ShieldCheck, ExternalLink } from 'lucide-react'
import { CONCIERGE_PRESETS, buildWhatsAppLink } from '../lib/whatsapp'

export default function WhatsAppConcierge({ open, setOpen }) {
  const [selected, setSelected] = useState(CONCIERGE_PRESETS[0])
  const [customMessage, setCustomMessage] = useState(CONCIERGE_PRESETS[0].message)

  function choosePreset(preset) {
    setSelected(preset)
    setCustomMessage(preset.message)
  }

  return (
    <>
      <motion.button
        onClick={() => setOpen(!open)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        aria-label="Open VIP Concierge chat"
        className="fixed bottom-6 right-6 z-40 flex items-center gap-2 rounded-full bg-gradient-to-r from-[#e8d9b5] via-[#c9a961] to-[#8a7444] px-5 py-3.5 text-sm font-semibold text-obsidian shadow-2xl shadow-black/50"
      >
        <MessageCircle className="h-4 w-4" strokeWidth={2} />
        <span className="hidden sm:inline">VIP Concierge</span>
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.96 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="fixed bottom-24 right-4 z-40 w-[calc(100vw-2rem)] max-w-sm overflow-hidden rounded-2xl border hairline bg-obsidian-2 shadow-2xl sm:right-6"
          >
            <div className="flex items-center justify-between border-b hairline bg-obsidian-3 px-5 py-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-[#e8d9b5] to-[#8a7444]">
                  <ShieldCheck className="h-5 w-5 text-obsidian" strokeWidth={2} />
                </div>
                <div>
                  <div className="text-sm font-semibold text-ink">
                    EliteVault VIP Concierge
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                    Online now
                  </div>
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="text-slate transition-colors hover:text-ink"
                aria-label="Close chat"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="p-5">
              <p className="text-sm text-slate">
                How can we assist you today? Choose an option or write your
                own message — we'll open it directly in WhatsApp.
              </p>

              <div className="mt-4 flex flex-wrap gap-2">
                {CONCIERGE_PRESETS.map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => choosePreset(preset)}
                    className={`rounded-full border px-3.5 py-1.5 text-xs font-medium transition-colors ${
                      selected.id === preset.id
                        ? 'border-gold bg-gold/10 text-gold-soft'
                        : 'hairline text-slate hover:border-gold/50'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              <textarea
                value={customMessage}
                onChange={(e) => setCustomMessage(e.target.value)}
                rows={4}
                className="vip-input mt-4 resize-none"
              />

              <a
                href={buildWhatsAppLink(customMessage)}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-[#25D366] px-5 py-3 text-sm font-semibold text-obsidian transition-transform hover:scale-[1.02]"
              >
                Continue on WhatsApp
                <ExternalLink className="h-4 w-4" strokeWidth={2} />
              </a>
              <p className="mt-3 text-center text-[11px] text-slate-dim">
                Typically replies within minutes, by appointment 24/7
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
