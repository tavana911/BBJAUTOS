import ConsignForm from './ConsignForm'

export default function ConsignSection() {
  return (
    <section id="consign" className="border-y hairline bg-obsidian-2/40">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-24 lg:grid-cols-[0.9fr_1.1fr] lg:px-10">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-gold-dim">
            Begin your consignment
          </p>
          <h2 className="mt-2 font-display text-3xl text-ink sm:text-4xl">
            Submit an Item for Consignment
          </h2>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-slate">
            Tell us about your piece and upload a photo. Our authentication
            team reviews every submission before white-glove pickup is
            arranged. You'll receive a tracking number the moment your
            submission is received.
          </p>

          <div className="mt-8 space-y-5">
            {[
              ['01', 'Submit', 'Share item details and a photo below'],
              ['02', 'Authenticate', 'Our experts verify and appraise'],
              ['03', 'List & sell', 'Your piece goes live to VIP buyers'],
              ['04', 'Get paid', 'Payout processed on sale'],
            ].map(([n, title, sub]) => (
              <div key={n} className="flex gap-4">
                <span className="font-mono text-sm text-gold-dim">{n}</span>
                <div>
                  <div className="text-sm font-medium text-ink">{title}</div>
                  <div className="text-xs text-slate-dim">{sub}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <ConsignForm />
      </div>
    </section>
  )
}
