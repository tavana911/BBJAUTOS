import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { supabase, isSupabaseConfigured } from '../lib/supabaseClient'
import { CATEGORIES, MOCK_PRODUCTS } from '../data/mockData'
import ProductCard from './ProductCard'

export default function Catalog() {
  const [products, setProducts] = useState(MOCK_PRODUCTS)
  const [activeCategory, setActiveCategory] = useState('all')
  const [loading, setLoading] = useState(isSupabaseConfigured)

  useEffect(() => {
    if (!isSupabaseConfigured) return

    async function load() {
      setLoading(true)
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false })
      if (!error && data) setProducts(data)
      setLoading(false)
    }
    load()
  }, [])

  const filtered =
    activeCategory === 'all'
      ? products
      : products.filter((p) => p.category === activeCategory)

  return (
    <section id="catalog" className="mx-auto max-w-7xl px-6 py-24 lg:px-10">
      <div className="mb-12 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-gold-dim">
            The vault
          </p>
          <h2 className="mt-2 font-display text-3xl text-ink sm:text-4xl">
            VIP Catalog
          </h2>
        </div>
        <p className="max-w-sm text-sm text-slate">
          Every piece independently authenticated before it ever reaches the
          floor.
        </p>
      </div>

      <div className="mb-10 grid grid-cols-2 gap-4 sm:grid-cols-4">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() =>
              setActiveCategory(activeCategory === cat.id ? 'all' : cat.id)
            }
            className={`group relative overflow-hidden rounded-xl border text-left transition-colors ${
              activeCategory === cat.id
                ? 'border-gold'
                : 'hairline hover:border-gold/50'
            }`}
          >
            <div className="aspect-[4/3] w-full overflow-hidden bg-obsidian-3">
              <img
                src={cat.image}
                alt={cat.name}
                loading="lazy"
                className="h-full w-full object-cover opacity-70 transition-all duration-500 group-hover:scale-105 group-hover:opacity-90"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-obsidian via-obsidian/20 to-transparent" />
            <div className="absolute bottom-0 left-0 p-3">
              <div className="text-sm font-semibold text-ink">{cat.name}</div>
              <div className="text-[11px] text-slate">{cat.description}</div>
            </div>
          </button>
        ))}
      </div>

      {loading ? (
        <div className="py-20 text-center text-sm text-slate">Loading catalog…</div>
      ) : (
        <motion.div
          layout
          className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4"
        >
          {filtered.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </motion.div>
      )}

      {!loading && filtered.length === 0 && (
        <div className="py-20 text-center text-sm text-slate">
          No pieces currently listed in this category.
        </div>
      )}
    </section>
  )
}
