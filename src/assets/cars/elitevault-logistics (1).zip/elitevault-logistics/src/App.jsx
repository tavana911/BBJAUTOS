import { useState } from 'react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import Catalog from './components/Catalog'
import ConsignSection from './components/ConsignSection'
import Footer from './components/Footer'
import TrackingModal from './components/TrackingModal'
import WhatsAppConcierge from './components/WhatsAppConcierge'

export default function App() {
  const [trackingCode, setTrackingCode] = useState(null)
  const [conciergeOpen, setConciergeOpen] = useState(false)

  return (
    <div className="min-h-screen bg-obsidian text-ink">
      <Navbar onOpenConcierge={() => setConciergeOpen(true)} />
      <Hero onTrack={setTrackingCode} />
      <Catalog />
      <ConsignSection />
      <Footer />

      <TrackingModal code={trackingCode} onClose={() => setTrackingCode(null)} />
      <WhatsAppConcierge open={conciergeOpen} setOpen={setConciergeOpen} />
    </div>
  )
}
