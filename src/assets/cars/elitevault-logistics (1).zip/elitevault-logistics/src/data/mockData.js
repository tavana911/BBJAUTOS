export const CATEGORIES = [
  {
    id: 'handbags',
    name: 'High-End Handbags',
    description: 'Hermès, Chanel & Louis Vuitton',
    image:
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=1200&auto=format&fit=crop',
  },
  {
    id: 'watches',
    name: 'Luxury Watches',
    description: 'Rolex, Patek Philippe & AP',
    image:
      'https://images.unsplash.com/photo-1523170335258-f5ed11844a49?q=80&w=1200&auto=format&fit=crop',
  },
  {
    id: 'jewelry',
    name: 'Fine Jewelry',
    description: 'Cartier, Tiffany & Van Cleef',
    image:
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=1200&auto=format&fit=crop',
  },
  {
    id: 'apparel',
    name: 'Collector Apparel',
    description: 'Runway & limited archive pieces',
    image:
      'https://images.unsplash.com/photo-1490114538077-0a7f8cb49891?q=80&w=1200&auto=format&fit=crop',
  },
]

export const MOCK_PRODUCTS = [
  {
    id: 'p1',
    title: 'Hermès Birkin 30 Togo Gold Hardware',
    price: 24500,
    category: 'handbags',
    condition: 'Pristine',
    image_url:
      'https://images.unsplash.com/photo-1591561954557-26941169b49e?q=80&w=800&auto=format&fit=crop',
    is_available: true,
  },
  {
    id: 'p2',
    title: 'Rolex Daytona 116500LN Panda Dial',
    price: 32800,
    category: 'watches',
    condition: 'Certified',
    image_url:
      'https://images.unsplash.com/photo-1547996160-81dfa63595aa?q=80&w=800&auto=format&fit=crop',
    is_available: true,
  },
  {
    id: 'p3',
    title: 'Cartier Love Bracelet 18k Yellow Gold',
    price: 6900,
    category: 'jewelry',
    condition: 'Like New',
    image_url:
      'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?q=80&w=800&auto=format&fit=crop',
    is_available: true,
  },
  {
    id: 'p4',
    title: 'Chanel Classic Flap Caviar Medium',
    price: 9800,
    category: 'handbags',
    condition: 'Pristine',
    image_url:
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=800&auto=format&fit=crop',
    is_available: true,
  },
  {
    id: 'p5',
    title: 'Patek Philippe Nautilus 5711/1A',
    price: 148000,
    category: 'watches',
    condition: 'Certified',
    image_url:
      'https://images.unsplash.com/photo-1523170335258-f5ed11844a49?q=80&w=800&auto=format&fit=crop',
    is_available: true,
  },
  {
    id: 'p6',
    title: 'Van Cleef & Arpels Alhambra Necklace',
    price: 5400,
    category: 'jewelry',
    condition: 'Like New',
    image_url:
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?q=80&w=800&auto=format&fit=crop',
    is_available: true,
  },
  {
    id: 'p7',
    title: 'Chanel Runway Tweed Jacket FW22',
    price: 4200,
    category: 'apparel',
    condition: 'Pristine',
    image_url:
      'https://images.unsplash.com/photo-1490114538077-0a7f8cb49891?q=80&w=800&auto=format&fit=crop',
    is_available: true,
  },
  {
    id: 'p8',
    title: 'Louis Vuitton Capucines BB',
    price: 5200,
    category: 'handbags',
    condition: 'Like New',
    image_url:
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?q=80&w=800&auto=format&fit=crop',
    is_available: true,
  },
]

// Demo tracking records — swap for live Supabase rows once connected.
export const MOCK_CONSIGNMENTS = {
  'EVL-89234': {
    tracking_number: 'EVL-89234',
    item_title: 'Hermès Birkin 30 Togo Gold Hardware',
    category: 'High-End Handbags',
    status: 'listed',
    estimated_value: 24500,
    updated_at: '2026-07-28T10:00:00Z',
  },
  'EVL-10042': {
    tracking_number: 'EVL-10042',
    item_title: 'Rolex Daytona 116500LN',
    category: 'Luxury Watches',
    status: 'authenticated',
    estimated_value: 32800,
    updated_at: '2026-07-30T14:30:00Z',
  },
  'EVL-55501': {
    tracking_number: 'EVL-55501',
    item_title: 'Cartier Love Bracelet',
    category: 'Fine Jewelry',
    status: 'paid',
    estimated_value: 6900,
    updated_at: '2026-07-20T09:15:00Z',
  },
}
