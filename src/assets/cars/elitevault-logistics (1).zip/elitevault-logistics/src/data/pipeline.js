export const PIPELINE_STAGES = [
  { key: 'pending', label: 'Pending Review' },
  { key: 'received', label: 'Received' },
  { key: 'authenticated', label: 'Inspected & Authenticated' },
  { key: 'listed', label: 'Listed for Sale' },
  { key: 'sold', label: 'Sold' },
  { key: 'paid', label: 'Payout Processed' },
]

export function stageIndex(status) {
  return PIPELINE_STAGES.findIndex((s) => s.key === status)
}
