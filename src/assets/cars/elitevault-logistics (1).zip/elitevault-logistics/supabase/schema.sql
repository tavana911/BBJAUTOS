-- =====================================================================
-- EliteVault Logistics — Supabase schema
-- Run this in the Supabase SQL editor (or via `supabase db push`).
-- =====================================================================

-- ---------------------------------------------------------------------
-- Extensions
-- ---------------------------------------------------------------------
create extension if not exists "pgcrypto"; -- gen_random_uuid()

-- ---------------------------------------------------------------------
-- Enum: consignment pipeline status
-- Mirrors the UI pipeline: Pending Review -> Received ->
-- Inspected & Authenticated -> Listed for Sale -> Sold -> Payout Processed
-- ---------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from pg_type where typname = 'consignment_status') then
    create type consignment_status as enum (
      'pending',
      'received',
      'authenticated',
      'listed',
      'sold',
      'paid'
    );
  end if;
end $$;

-- ---------------------------------------------------------------------
-- Table: consignments
-- ---------------------------------------------------------------------
create table if not exists public.consignments (
  id                uuid primary key default gen_random_uuid(),
  tracking_number   text not null unique,
  client_name       text not null,
  client_email      text not null,
  item_title        text not null,
  category          text not null,
  status            consignment_status not null default 'pending',
  estimated_value   numeric(12, 2),
  image_path        text, -- storage object path in the consignment-images bucket
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

-- Public lookups happen by tracking_number, so index it explicitly
-- (in addition to the implicit unique index).
create index if not exists consignments_tracking_number_idx
  on public.consignments (tracking_number);

create index if not exists consignments_status_idx
  on public.consignments (status);

-- Keep updated_at current on every row change
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists consignments_set_updated_at on public.consignments;
create trigger consignments_set_updated_at
  before update on public.consignments
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------
-- Table: products (public catalog)
-- ---------------------------------------------------------------------
create table if not exists public.products (
  id            uuid primary key default gen_random_uuid(),
  title         text not null,
  price         numeric(12, 2) not null,
  category      text not null,
  condition     text not null check (condition in ('Pristine', 'Like New', 'Certified')),
  image_url     text,
  is_available  boolean not null default true,
  created_at    timestamptz not null default now()
);

create index if not exists products_category_idx on public.products (category);
create index if not exists products_is_available_idx on public.products (is_available);

-- =====================================================================
-- Row Level Security
-- =====================================================================
alter table public.consignments enable row level security;
alter table public.products enable row level security;

-- --- consignments -----------------------------------------------------
-- Anonymous/public users may INSERT a new consignment (the intake form)
-- but may only SELECT the limited fields needed for tracking, and only
-- when they already know the exact tracking number (enforced client-side
-- via .eq('tracking_number', code) — RLS still allows broader reads here
-- for simplicity, so tighten with a SECURITY DEFINER RPC if you need to
-- hide client PII from anonymous readers).
drop policy if exists "Public can submit consignments" on public.consignments;
create policy "Public can submit consignments"
  on public.consignments
  for insert
  to anon, authenticated
  with check (status = 'pending');

drop policy if exists "Public can look up consignments by tracking number" on public.consignments;
create policy "Public can look up consignments by tracking number"
  on public.consignments
  for select
  to anon, authenticated
  using (true);

-- Only staff (service_role, or authenticated users flagged as admin via
-- a custom claim / admins table) may update status or delete records.
-- Adjust the `is_admin` check to match your auth setup, e.g. a JWT claim
-- or membership in an `admins` table.
drop policy if exists "Admins can update consignments" on public.consignments;
create policy "Admins can update consignments"
  on public.consignments
  for update
  to authenticated
  using (coalesce((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false))
  with check (coalesce((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false));

drop policy if exists "Admins can delete consignments" on public.consignments;
create policy "Admins can delete consignments"
  on public.consignments
  for delete
  to authenticated
  using (coalesce((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false));

-- --- products -----------------------------------------------------
drop policy if exists "Public can view available products" on public.products;
create policy "Public can view available products"
  on public.products
  for select
  to anon, authenticated
  using (true);

drop policy if exists "Admins can manage products" on public.products;
create policy "Admins can manage products"
  on public.products
  for all
  to authenticated
  using (coalesce((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false))
  with check (coalesce((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false));

-- =====================================================================
-- Storage: consignment intake photos
-- =====================================================================
insert into storage.buckets (id, name, public)
values ('consignment-images', 'consignment-images', true)
on conflict (id) do nothing;

drop policy if exists "Public can upload consignment images" on storage.objects;
create policy "Public can upload consignment images"
  on storage.objects
  for insert
  to anon, authenticated
  with check (bucket_id = 'consignment-images');

drop policy if exists "Public can view consignment images" on storage.objects;
create policy "Public can view consignment images"
  on storage.objects
  for select
  to anon, authenticated
  using (bucket_id = 'consignment-images');

-- =====================================================================
-- Realtime (optional): enables live status updates on the tracking page
-- =====================================================================
alter publication supabase_realtime add table public.consignments;

-- =====================================================================
-- Seed data (optional — safe to remove)
-- =====================================================================
insert into public.products (title, price, category, condition, image_url, is_available)
values
  ('Hermès Birkin 30 Togo Gold Hardware', 24500, 'handbags', 'Pristine',
   'https://images.unsplash.com/photo-1591561954557-26941169b49e?q=80&w=800&auto=format&fit=crop', true),
  ('Rolex Daytona 116500LN Panda Dial', 32800, 'watches', 'Certified',
   'https://images.unsplash.com/photo-1547996160-81dfa63595aa?q=80&w=800&auto=format&fit=crop', true),
  ('Cartier Love Bracelet 18k Yellow Gold', 6900, 'jewelry', 'Like New',
   'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?q=80&w=800&auto=format&fit=crop', true)
on conflict do nothing;

insert into public.consignments (tracking_number, client_name, client_email, item_title, category, status, estimated_value)
values
  ('EVL-89234', 'Amara Okafor', 'amara@example.com', 'Hermès Birkin 30 Togo Gold Hardware', 'High-End Handbags', 'listed', 24500),
  ('EVL-10042', 'Daniel Cho', 'daniel@example.com', 'Rolex Daytona 116500LN', 'Luxury Watches', 'authenticated', 32800),
  ('EVL-55501', 'Priya Sharma', 'priya@example.com', 'Cartier Love Bracelet', 'Fine Jewelry', 'paid', 6900)
on conflict (tracking_number) do nothing;
