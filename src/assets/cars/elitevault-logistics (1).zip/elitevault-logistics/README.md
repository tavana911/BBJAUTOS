# EliteVault Logistics

A VIP luxury consignment and logistics web app: dynamic tracking pipeline,
a floating WhatsApp VIP concierge, a curated catalog, and a consignment
intake form with photo upload — built on React, Vite, Tailwind CSS,
Framer Motion, and Supabase.

## Stack

- **Frontend:** React 19 + Vite + Tailwind CSS v4, Framer Motion, Lucide icons
- **Backend:** Supabase (Postgres, Auth, Storage, Realtime)

## Getting started

```bash
npm install
cp .env.example .env   # then fill in your Supabase project URL + anon key
npm run dev
```

The app works out of the box in **demo mode** with mock data if you don't
configure Supabase yet — try the tracking bar with `EVL-89234`,
`EVL-10042`, or `EVL-55501`.

## Connecting Supabase

1. Create a project at [supabase.com](https://supabase.com).
2. Open the SQL editor and run `supabase/schema.sql`. This creates:
   - the `consignments` table (with a `consignment_status` enum, unique
     indexed `tracking_number`, and an `updated_at` trigger)
   - the `products` table
   - Row Level Security policies (public insert + read for consignments
     and product browsing; admin-only updates/deletes gated on an
     `is_admin` JWT app_metadata claim — adjust to your auth model)
   - the public `consignment-images` Storage bucket + policies
   - realtime publication for live status updates
   - a few seed rows matching the demo tracking codes
3. Copy your project's **Project URL** and **anon public key** from
   *Project Settings → API* into `.env`.
4. Restart `npm run dev`. The tracking search, catalog, and consign form
   will now read/write live Supabase data.

## Admin status updates

The `consignments.status` column drives the tracking pipeline shown to
customers (`pending → received → authenticated → listed → sold → paid`).
Update it from the Supabase Table Editor, a small internal admin screen,
or any authenticated client whose JWT carries `app_metadata.is_admin = true`
— the RLS policies restrict writes to that role. Because the table is
added to the `supabase_realtime` publication, any subscribed tracking
view updates live the moment status changes.

## WhatsApp concierge number

Update `WHATSAPP_NUMBER` in `src/lib/whatsapp.js` with EliteVault's live
concierge line (E.164 format, digits only, no leading `+`).

## Project structure

```
src/
  components/     UI components (Navbar, Hero, Catalog, ConsignForm, ...)
  data/           Mock data + pipeline stage config (demo-mode fallback)
  lib/            Supabase client + WhatsApp helper
supabase/
  schema.sql      Full Postgres schema, RLS policies, storage bucket
```
